# JMCAI 帮助中心截图规范

本目录用于存放帮助中心文章的截图资源。

## 目录规则

- 中文截图统一放在 `zh-CN/<category>/<slug>/`
- 每篇核心文章使用独立目录，不混放
- 目录命名必须与文章 `category` 和 `slug` 完全一致

## 文件命名

- `01-entry.webp`
- `02-key-step.webp`
- `03-success-state.webp`
- `04-error-state.webp` 仅排障类文章可选

## 采集要求

- 截图必须基于当前版本界面，不得混用旧界面
- 入口图展示页面或模块进入位置
- 关键步骤图展示用户真正要执行的动作
- 成功状态图展示结果出现后的判断依据
- 错误状态图仅用于排障类文章，且必须遮蔽敏感信息

## 安全要求

- 不得暴露账号、邮箱、密钥、Token、节点地址、个人文件路径
- 如需展示示例数据，优先使用脱敏样例

## 本轮 Sprint 1 核心文章目录

- `zh-CN/getting-started/getting-started/`
- `zh-CN/getting-started/first-successful-run/`
- `zh-CN/installation/environment-setup/`
- `zh-CN/connections/first-comfyui-connection/`
- `zh-CN/workflows/workflow-lab/`
- `zh-CN/workflows/import-and-save-workflows/`
- `zh-CN/gallery/gallery-management/`
- `zh-CN/gallery/download-and-export-results/`
- `zh-CN/troubleshooting/common-issues/`
- `zh-CN/troubleshooting/startup-connection-execution-checklist/`
