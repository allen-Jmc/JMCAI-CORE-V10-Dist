import{ag as r}from"./index-BRX993X6.js";const a=()=>r();export{a as u};
