const i="{{input}}";function o(n){var t;return(t=n.toolId)!=null&&t.trim()?"execution":"thinking"}export{i as D,o as g};
